import NavBar from "../common/NavBar";

export default function Inicio() {
    return (
        <div>
            <NavBar/>
        </div>
    )
}
