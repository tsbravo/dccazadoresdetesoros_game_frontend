const API_URL = "https://dccazadoresdetesoros.onrender.com";

export default API_URL;